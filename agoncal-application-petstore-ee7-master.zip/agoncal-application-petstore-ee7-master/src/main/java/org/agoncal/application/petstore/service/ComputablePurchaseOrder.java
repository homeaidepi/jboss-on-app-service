package org.agoncal.application.petstore.service;

public interface ComputablePurchaseOrder
{
}