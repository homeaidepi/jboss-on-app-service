package org.agoncal.application.petstore.service;

import org.agoncal.application.petstore.util.Loggable;

@Loggable
public class InventoryService
{
}