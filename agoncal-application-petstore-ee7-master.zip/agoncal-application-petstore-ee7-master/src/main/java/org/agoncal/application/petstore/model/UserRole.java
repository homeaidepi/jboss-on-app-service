package org.agoncal.application.petstore.model;

/**
 * @author Antonio Goncalves - http://www.antoniogoncalves.org --
 */
public enum UserRole
{
   // ======================================
   // = Attributes =
   // ======================================

   USER, ADMIN
}
